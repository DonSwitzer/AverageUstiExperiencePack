

Average modpack for all people to feel what it is like to be in the worst city in Czechia, Usti nad Labem...

A modpack for all sort of people

Versions:
1.0.0 - testing alpha version
1.5.0 - added ChomutovCzechShining /
(includes these mods: 
"Toybox-LittleCompany-1.3.16",
"jaspercreations-Scopophobia-1.1.5",
"super_fucking_cool_and_badass_team-Biodiversity-0.1.4",
"Feiryn-LethalMon-0.6.7",
"Alice-ScarletDevilMansion-2.1.0",
"Plastered_Crab-Black_Mesa_Half_Life_Moon_Interior-3.0.3",
"DemonMae-unreal_interiors-1.9.2",
"KayNetsua-E_Gypt_Moon-2.0.21",
"Piggy-LC_Office-1.2.5",
"Ccode_lang-SirenHead-2.0.3",
"MeatBallDemon-VileVendingMachine-1.1.2",
"ProjectSCP-SCP966-1.1.5",
"malco-Lategame_Upgrades-3.11.0",
"ProjectSCP-SCP173-1.0.1",
"Nikki-Slaughterhouse-1.0.6",
"Piggy-Piggys_Variety_Mod-1.3.17",
"TimMods-CzechCompany-0.1.2",
"Magic_Wesley-WesleysInteriors-1.6.2"
) /
1.5.5 - (removed "RickArg-Helmet_Cameras-2.1.5",
"SquidyBallinxGaming-ShipTurrets-1.0.6") /
1.6.2 - (removed "ohotdog-LootableMusicTapes-1.0.1","Renegades-WalkieUse-1.5.0","Steven-Custom_Boombox_Music-1.4.0", added "Backrooms-Backrooms-0.1.3","Evaisa-LethalThings-0.10.6","Archie-YoutubeBoomBox-1.0.6","5Bit-VoiceHUD-1.0.4") /
1.6.6 - (removed "Suskitech-AlwaysHearActiveWalkies-1.4.5") /
1.6.8 - (updates) /
